import UIKit

class AddToDoItemViewController: UIViewController {

    var toDoItem: ToDoItem? = nil

    @IBOutlet weak var textField: UITextField!
    @IBOutlet weak var saveButton: UIBarButtonItem!
    @IBOutlet weak var switchPublica: UISwitch!

    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

    // MARK: - Navegación

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if (saveButton.isEqual(sender)) && (textField.text!.count > 0) {
            let nombre = textField.text!
            let esPublica = switchPublica.isOn
            toDoItem = ToDoItem(nombre: nombre, esPublica: esPublica)
        }
    }
}
