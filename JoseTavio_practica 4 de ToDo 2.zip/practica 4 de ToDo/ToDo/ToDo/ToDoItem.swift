import UIKit

class ToDoItem: NSObject {
    var nombreItem: String
    var completado: Bool = false
    var fechaFinalizacion: Date? = nil
    var esPublica: Bool = false  // Nueva propiedad para CloudKit pública

    init(nombre: String, esPublica: Bool = false) {
        self.nombreItem = nombre
        self.esPublica = esPublica
    }
}
