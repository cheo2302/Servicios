import UIKit
import CloudKit

class ToDoTableViewController: UITableViewController {

    var toDoItems = [ToDoItem]()
    var itemsTerminados = 0

    func borraItems() {
        var itemsPendientes = [ToDoItem]()
        itemsTerminados = 0

        for toDoItem in toDoItems {
            if !toDoItem.completado {
                itemsPendientes.append(toDoItem)
            } else {
                itemsTerminados += 1
            }
        }

        toDoItems = itemsPendientes
        tableView.reloadData()

        let iCloudStore = NSUbiquitousKeyValueStore.default
        iCloudStore.set(itemsTerminados, forKey: "itemsTerminados")
        iCloudStore.synchronize()
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        // Recuperar valor clave-valor
        let iCloudStore = NSUbiquitousKeyValueStore.default
        itemsTerminados = Int(iCloudStore.longLong(forKey: "itemsTerminados"))

        // Pull to refresh
        refreshControl = UIRefreshControl()
        refreshControl?.addTarget(self, action: #selector(recargarDatosDesdeCloudKit), for: .valueChanged)

        recargarDatosDesdeCloudKit()
    }

    // MARK: - Tabla

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return toDoItems.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ListPrototypeCell", for: indexPath)

        let toDoItem = toDoItems[indexPath.row]
        cell.textLabel!.text = toDoItem.nombreItem
        cell.textLabel!.textColor = toDoItem.esPublica ? .red : .black
        cell.accessoryType = toDoItem.completado ? .checkmark : .none

        return cell
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: false)
        let itemPulsado = toDoItems[indexPath.row]
        itemPulsado.completado.toggle()
        itemPulsado.fechaFinalizacion = Date()
        tableView.reloadRows(at: [indexPath], with: .none)
    }

    // MARK: - CloudKit

    func guardarTareaEnCloudKit(_ tarea: ToDoItem) {
        let record = CKRecord(recordType: "Tarea")
        record["nombre"] = tarea.nombreItem as CKRecordValue
        record["esPublica"] = tarea.esPublica as CKRecordValue

        let db: CKDatabase = tarea.esPublica
            ? CKContainer.default().publicCloudDatabase
            : CKContainer.default().privateCloudDatabase

        db.save(record) { savedRecord, error in
            if let error = error {
                print("❌ Error al guardar en CloudKit: \(error)")
            } else {
                print("✅ Tarea guardada en \(tarea.esPublica ? "📢 pública" : "🔒 privada"): \(tarea.nombreItem)")
            }
        }
    }

    @objc func recargarDatosDesdeCloudKit() {
        toDoItems = []

        let grupo = DispatchGroup()

        grupo.enter()
        cargarTareasDesdeCloudKit(privada: true) {
            grupo.leave()
        }

        grupo.enter()
        cargarTareasDesdeCloudKit(privada: false) {
            grupo.leave()
        }

        grupo.notify(queue: .main) {
            self.tableView.reloadData()
            self.refreshControl?.endRefreshing()
        }
    }

    func cargarTareasDesdeCloudKit(privada: Bool, completion: @escaping () -> Void) {
        let db = privada
            ? CKContainer.default().privateCloudDatabase
            : CKContainer.default().publicCloudDatabase

        let query = CKQuery(recordType: "Tarea", predicate: NSPredicate(value: true))

        db.perform(query, inZoneWith: nil) { records, error in
            if let error = error {
                print("❌ Error al recuperar \(privada ? "privadas" : "públicas"): \(error)")
            } else {
                let nuevas = records?.compactMap { record -> ToDoItem? in
                    guard let nombre = record["nombre"] as? String else { return nil }
                    let esPublica = record["esPublica"] as? Bool ?? !privada
                    return ToDoItem(nombre: nombre, esPublica: esPublica)
                } ?? []

                self.toDoItems.append(contentsOf: nuevas)
            }
            completion()
        }
    }

    // MARK: - Navegación

    @IBAction func unWindToList(_ segue: UIStoryboardSegue) {
        let fuente = segue.source as! AddToDoItemViewController
        if let item = fuente.toDoItem {
            toDoItems.append(item)
            tableView.reloadData()
            guardarTareaEnCloudKit(item)
        }
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "ItemsTerminados" {
            if let destinationVC = segue.destination as? NumItemsViewController {
                borraItems()
                destinationVC.terminados = itemsTerminados
            }
        }
    }
}
