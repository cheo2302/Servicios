# 📋 ToDoList con iCloud y CloudKit

**Alumno:** José Tavio  
**Bundle ID:** ua.mudsdm.ToDo  
**Contenedor iCloud:** iCloud.es.ua.mudsdm.ToDo  

## 🧾 Descripción general del proyecto

Esta app permite gestionar una lista de tareas tipo ToDo. Se ha ampliado para integrar **almacenamiento en iCloud** (clave-valor y CloudKit), permitiendo al usuario sincronizar información entre dispositivos y compartir tareas públicamente.

---

## ✅ Funcionalidades implementadas

### 🔹 1. Tareas ToDo básicas
- Añadir y marcar tareas como completadas.
- Contador de tareas completadas.
- Interfaz basada en Storyboards.

### 🔹 2. Notificaciones locales
- Botón que lanza una notificación local con imagen y acciones (`HECHO`, `RECORDAR`).
- Al reabrir la app, se muestra un `UIAlert` con la acción que seleccionó el usuario.

### 🔹 3. iCloud (clave-valor)
- El número de tareas completadas se guarda automáticamente en iCloud.
- Se recupera el valor al iniciar la app, permitiendo sincronización entre dispositivos.

### 🔹 4. CloudKit - base de datos privada
- Las tareas se almacenan en la base de datos privada del usuario.
- Se cargan automáticamente al iniciar la app.

### 🔹 5. CloudKit - base de datos pública
- Al añadir una tarea, se puede marcar como **pública** mediante un `UISwitch`.
- Las tareas públicas se guardan en la base de datos pública de CloudKit.
- Se muestran con un **color de texto diferente (rojo)** en la lista.

### 🔹 6. Recarga con "pull to refresh"
- Se puede tirar de la tabla hacia abajo para recargar los datos desde iCloud.

---

## ⚙️ Clases principales

| Clase                       | Función                                                                 |
|----------------------------|-------------------------------------------------------------------------|
| `ToDoItem`                 | Modelo de datos para una tarea. Incluye nombre, estado, fecha y flag pública. |
| `ToDoTableViewController`  | Controlador principal con tabla de tareas. Integra iCloud y CloudKit.   |
| `AddToDoItemViewController`| Pantalla para añadir nuevas tareas. Permite marcar tareas como públicas. |
| `AppDelegate`              | Manejo de permisos, notificaciones locales y recuperación de acciones. |

---

## ❗️Dificultades encontradas y soluciones

- **Error Not Authenticated en CloudKit**: Ocurre si no hay una sesión activa de iCloud en el dispositivo/simulador. Solución: iniciar sesión en iCloud desde Ajustes > Apple ID.
- **Sincronización de clave-valor**: Puede requerir `NSUbiquitousKeyValueStore.default.synchronize()` después de guardar.
- **Actualizar tabla desde hilos secundarios**: Se utiliza `DispatchQueue.main.async` para recargar correctamente la interfaz después de las queries.

---

## 📌 Requisitos

- iOS 15 o superior.
- Perfil de aprovisionamiento con permisos de iCloud (clave-valor y CloudKit).
- Activar `Background Modes > Remote notifications` si se extiende a sincronización en tiempo real.

---

## 🗃️ Recursos usados

- CloudKit Dashboard: https://icloud.developer.apple.com
- Imagen para notificación: `check.png` incluida en Assets.

---

## 📦 Instrucciones de compilación

1. Asegúrate de tener un Apple ID con iCloud activado.
2. Usa Xcode con un dispositivo o simulador con sesión de iCloud activa.
3. Selecciona un perfil de aprovisionamiento válido.
4. Compila y ejecuta.

---

© 2025 Universidad de Alicante – Máster en Desarrollo de Sistemas para Dispositivos Móviles.
